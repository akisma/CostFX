import boto3
import json
import os
from datetime import datetime, timedelta

def handler(event, context):
    """
    Cost optimization lambda for development environment
    - Clean up old CloudWatch logs
    - Remove old ECS task definitions
    - Clean up unused resources
    """
    
    environment = os.environ.get('ENVIRONMENT', 'dev')
    app_name = os.environ.get('APP_NAME', 'costfx')
    
    if environment != 'dev':
        return {
            'statusCode': 200,
            'body': json.dumps('Cost optimizer only runs in dev environment')
        }
    
    try:
        # CloudWatch Logs cleanup
        logs_client = boto3.client('logs')
        cutoff_date = datetime.now() - timedelta(days=7)
        
        # List and clean old log streams
        log_groups = [
            f'/ecs/{app_name}-{environment}-backend',
            f'/ecs/{app_name}-{environment}-frontend',
            f'/aws/wafv2/{app_name}-{environment}'
        ]
        
        cleaned_streams = 0
        for log_group in log_groups:
            try:
                streams = logs_client.describe_log_streams(
                    logGroupName=log_group,
                    orderBy='LastEventTime'
                )
                
                for stream in streams['logStreams']:
                    if 'lastEventTime' in stream:
                        last_event = datetime.fromtimestamp(stream['lastEventTime'] / 1000)
                        if last_event < cutoff_date:
                            logs_client.delete_log_stream(
                                logGroupName=log_group,
                                logStreamName=stream['logStreamName']
                            )
                            cleaned_streams += 1
            except Exception as e:
                print(f"Error cleaning log group {log_group}: {str(e)}")
        
        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': f'Cost optimization completed',
                'cleaned_log_streams': cleaned_streams,
                'timestamp': datetime.now().isoformat()
            })
        }
        
    except Exception as e:
        print(f"Error in cost optimizer: {str(e)}")
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error: {str(e)}')
        }
